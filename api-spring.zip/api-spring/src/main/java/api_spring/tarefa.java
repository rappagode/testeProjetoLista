package api_spring;

public interface tarefa {
}
